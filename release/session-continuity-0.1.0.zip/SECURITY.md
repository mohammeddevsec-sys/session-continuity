# Security Model

The receipt is untrusted input.

Trust is established from an externally provisioned signing authority. The receipt does not contain the authoritative trust store.

The signing private key must remain protected by the operator and must never be distributed with a receipt.

The current CLI supports authority provisioning, status inspection, and signer revocation. Trust rotation is not exposed as a CLI operation in this release and is therefore not described as an end-user command.

The engine does not validate OIDC JWT signatures. Identity-provider authentication and claim verification remain outside this product boundary.

Durable challenge, sequence, proof-of-possession, evidence, lineage, certificate, and trust checks are independently verified by the receiver.

A revoked signer must be rejected even when its receipt remains cryptographically intact.

No security product can guarantee detection of every attack. This product provides deterministic proof for the properties implemented and tested by the release.
