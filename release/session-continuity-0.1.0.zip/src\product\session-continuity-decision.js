import { executeTransactionalFinalProofPipeline } from "../core/transactional-final-proof-pipeline.js";
import { evaluateSessionContinuityPolicy } from "../policy/session-continuity-policy.js";
import { signSessionProvenanceCertificate } from "../evidence/session-provenance-certificate.js";

export function executeSessionContinuityDecision(input) {
  try {
    const pipeline = executeTransactionalFinalProofPipeline(input);

    const policy = evaluateSessionContinuityPolicy({
      engineDecision: pipeline.decision,
      reason: pipeline.reason,
      committed: pipeline.committed === true,
      certificatePresent: pipeline.certificate !== null && pipeline.certificate !== undefined,
      bindingValid: pipeline.verification?.binding_valid === true,
      offlineVerified: pipeline.verification?.offline?.verified === true,
      trustedVerified: pipeline.verification?.trusted?.verified === true
    });

    const provenanceCertificate =
      policy.decision === "ALLOW"
        ? signSessionProvenanceCertificate(input.signingIdentity, {
            session_id: input.anchor.sessionId,
            subject: input.anchor.subject,
            issuer: input.anchor.issuer,
            decision: policy.decision,
            policy_fingerprint_sha256: policy.policy_fingerprint_sha256,
            bundle_root_sha256: pipeline.proof.bundle_root_sha256,
            lineage_root_sha256: pipeline.proof.lineage_root_sha256,
            merkle_root_sha256: pipeline.proof.merkle_root_sha256,
            evidence_fingerprint_sha256: pipeline.proof.evidence_fingerprint_sha256,
            sequence: input.presented.sequence
          })
        : null;

    return Object.freeze({
      decision: policy.decision,
      reason: policy.reason,
      policy,
      provenanceCertificate,
      pipeline
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    const policy = evaluateSessionContinuityPolicy({
      engineDecision: "CONTINUOUS",
      reason: message,
      committed: false,
      certificatePresent: true,
      bindingValid: false,
      offlineVerified: false,
      trustedVerified: false
    });

    return Object.freeze({
      decision: policy.decision,
      reason: policy.reason,
      policy,
      provenanceCertificate: null,
      pipeline: null,
      error: message
    });
  }
}