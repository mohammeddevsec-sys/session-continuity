# Changelog

## 0.1.0

Initial product release candidate with durable session continuity, proof-of-possession, evidence integrity, provenance certificates, external trust authority, signer revocation, independent verification, and CLI operation.
