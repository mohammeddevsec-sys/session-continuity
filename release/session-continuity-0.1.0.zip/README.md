# Session Continuity

Vendor-neutral session continuity and provenance proof product.

## Purpose

Proves that an accepted application session is the legitimate continuation of the authenticated session that created it.

## Boundary

This product is not an identity provider, OAuth/OIDC implementation, SIEM, UEBA platform, AI security platform, or vulnerability scanner.

OIDC/JWT validation is outside this engine. The caller supplies claims only after independent verification.

## CLI

Provision a signing authority:
node bin/session-continuity.mjs authority-init --output <authority-directory>

Inspect authority status:
node bin/session-continuity.mjs authority-status --authority <authority-directory>

Revoke the authority signer:
node bin/session-continuity.mjs authority-revoke --authority <authority-directory>

Create a proof:
node bin/session-continuity.mjs prove --claims <verified-claims.json> --output <receipt-directory> --authority <authority-directory> --client-id <client-id> --device-id <device-id>

Verify independently:
node bin/session-continuity.mjs verify --input <receipt-directory> --trust <authority-directory>\\trust

The trust authority is external to the receipt. The current CLI exposes authority provisioning, status, revocation, proof generation, and independent verification.

## Verified claims

The claims file must contain verified=true, sub, iss, sid, auth_time, and aud.

## Security properties

Durable challenges, replay protection, proof of possession, atomic acceptance, tamper-evident evidence, lineage, Merkle binding, signed provenance certificates, durable trust, trust revocation, and independent verification.

## Demo

node bin/demo.mjs

The demo uses a local verified fixture and does not contact a real identity provider.
